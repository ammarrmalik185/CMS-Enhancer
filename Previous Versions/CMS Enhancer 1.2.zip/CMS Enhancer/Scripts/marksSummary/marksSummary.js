let userSettingMarks = {
    'markSummary_enable' : true,
    'markSummary_marks_total' : true,
    'markSummary_marks_theory' : true,
    'markSummary_marks_lab' : true,
    'markSummary_tableData_accounted' : true,
    'markSummary_tableData_intermediate' : true,
    'markSummary_tableData_absolute' : true,
    'markSummary_removeDuplicateEntries' : true,
}

function initMarks() {
    chrome.storage.sync.get(Object.keys(userSettingMarks), results => {
        sendConsoleMessage(results)
        for (let option in userSettingMarks) {
            if (results.hasOwnProperty(option)) {
                userSettingMarks[option] = results[option]
                sendConsoleMessage(`${option} is ${results[option]}`)
            } else {
                chrome.storage.sync.set({[option]: true}, () => {
                    if (chrome.runtime.lastError) {
                        sendConsoleMessage("Error retrieving index: " + chrome.runtime.lastError);
                    }
                    sendConsoleMessage(`${option} is set to ${true}`);
                });
                userSettingMarks[option] = true;
            }
        }
        startMarks();
    });
}

function startMarks() {
    if (userSettingMarks.markSummary_enable) {
        getMetaData();
        getTables();

        calculateWeights();
        calculateMarks();
        calculateFinalMarks();

        if (userSettingMarks.markSummary_removeDuplicateEntries) removeDuplicateRows();

        showFinalMarks();

        addRowsToTable();

        sendConsoleMessage(markWeights);
        sendConsoleMessage(gainedMarksRaw);
        sendConsoleMessage(gainedMarks);
        sendConsoleMessage(finalMarks);
        sendConsoleMessage(tables);
    }
}

initMarks();