
function init(){

    if (window.location.href.includes("/ResultCard")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastResultPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastResultPopup': "placeholder"}, function() {});
    }
    if (window.location.href.includes("/Courses")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastPopup': "placeholder"}, function() {});
    }

    chrome.storage.local.get(['setDarkMode', 'gpaCalculate', 'marksCalculate', 'removePopup'], function(result) {
        if (result['gpaCalculate'] === undefined){
            chrome.storage.local.set({'gpaCalculate': true}, function() {});
            calculateGpa();
        }
        else {
            if (result['gpaCalculate']){
                calculateGpa();
            }
        }

        if (result['marksCalculate'] === undefined){
            chrome.storage.local.set({'marksCalculate': true}, function() {});
            calculateInternalMarks();
        }
        else{
            if (result['marksCalculate']){
                calculateInternalMarks();
            }
        }

        if (result['removePopup'] === undefined){
            chrome.storage.local.set({'removePopup': false}, function() {});
        }
        else{
            if (result['removePopup']){
                removePopups();
            }
        }

        if (result['setDarkMode'] === undefined){
            chrome.storage.local.set({'setDarkMode': false}, function() {});
        }
        else{
            if (result['setDarkMode']){
                darkMode();
            }
        }
    });
}

// init();




