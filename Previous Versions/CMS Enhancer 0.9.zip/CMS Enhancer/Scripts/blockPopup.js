function removePopups() {
    if (window.location.href.includes("/Courses")) {
        let popup = document.getElementById("myModal");
        if (popup !== null) {
            chrome.storage.local.get(['lastPopup'], function (result) {
                if (result['lastPopup'] === undefined) {
                    chrome.storage.local.set({'lastPopup': popup.textContent}, function () {
                    });
                } else if (result['lastPopup'] === popup.textContent) {
                    popup.style["display"] = "none";
                } else {
                    chrome.storage.local.set({'lastPopup': popup.textContent}, function () {
                    });
                }

            });
        }

    }
    if (window.location.href.includes("/ResultCard")) {
        let popup = document.getElementById("myModal");
        if (popup !== null) {
            chrome.storage.local.get(['lastResultPopup'], function (result) {
                if (result['lastResultPopup'] === undefined) {
                    chrome.storage.local.set({'lastResultPopup': popup.textContent}, function () {
                    });
                } else if (result['lastResultPopup'] === popup.textContent) {
                    popup.style["display"] = "none";
                } else {
                    chrome.storage.local.set({'lastResultPopup': popup.textContent}, function () {});
                }

            });
        }

    }
}

function init() {
    if (window.location.href.includes("/ResultCard")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastResultPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastResultPopup': "placeholder"}, function() {});
    }
    if (window.location.href.includes("/Courses")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastPopup': "placeholder"}, function() {});
    }

    chrome.storage.local.get(['removePopup'], function(result) {
        if (result['removePopup'] === undefined){
            chrome.storage.local.set({'removePopup': false}, function() {});
        }
        else{
            if (result['removePopup']){
                removePopups();
            }
        }
    });

}

console.log("block popup")

init();