let element = document.getElementById("leftSideBar");
let width = element.style["width"];
element.style["width"] = 0;
element.style["width"] = width;