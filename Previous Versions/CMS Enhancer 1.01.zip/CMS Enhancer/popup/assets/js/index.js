let checkBoxes = [
    'visualCustomization_enable',
    'visualCustomization_darkMode',

    'markSummary_enable',
    'markSummary_marks_total',
    'markSummary_marks_theory',
    'markSummary_marks_lab',
    'markSummary_tableData_accounted',
    'markSummary_tableData_intermediate',
    'markSummary_tableData_absolute',
    'markSummary_removeDuplicateEntries',

    'resultCard_enable',
    'resultCard_showGPA',

    'blocking_enable',
    'blocking_blockPopups',
]

function run() {
    chrome.storage.sync.get(checkBoxes, results => {
        console.log(results)
        for (let currentCheckBox of checkBoxes) {
            if (results.hasOwnProperty(currentCheckBox)) {
                document.getElementById(currentCheckBox).checked = results[currentCheckBox]
                console.log(`${currentCheckBox} is ${results[currentCheckBox]}`)
            } else {
                chrome.storage.sync.set({[currentCheckBox]: true}, () => {
                    if (chrome.runtime.lastError) {
                        console.log("Error retrieving index: " + chrome.runtime.lastError);
                    }
                    console.log(`${currentCheckBox} is set to ${true}`);
                });
                document.getElementById(currentCheckBox).checked = true;
            }
        }
    });



    for (let currentCheckBox of checkBoxes){
        let element = document.getElementById(currentCheckBox);
        document.getElementById(currentCheckBox).addEventListener("click", () => {
            chrome.storage.sync.set({[currentCheckBox]: element.checked}, () => {
                if (chrome.runtime.lastError) {
                    console.log("Error retrieving index: " + chrome.runtime.lastError);
                }
                console.log(`${currentCheckBox} is set to ${element.checked}`);
            });
        })
    }
}

run();