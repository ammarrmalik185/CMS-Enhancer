let complete_marks_data = {
    "Quizzes":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Assignments":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Lab Sessional 1":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Sessional 1":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Sessional 2":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Lab Sessional 2":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Lab Assignments":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "Final":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
    "FinalLab":{
        "total_marks_accounted":0,
        "weight_single_marks":0,
        "weight_grand_total":0,
        "weight_sub_total":0,
        "obtained_marks_accounted":0,
    },
};
let roundFigure = 100;

// console.log("CMS Enhancer Running");

function darkMode() {
    let body = document.getElementsByTagName('body');
    for (let i = 0; i < body.length; i++) {
        body[i].style['background-color'] = '#000000';
    }
    let background_image = document.getElementsByTagName('div');
    for (let i = 0; i < background_image.length; i++) {
        background_image[i].style['background-color'] = '#000000';
        background_image[i].style['background'] = '#000000';
        background_image[i].style['color'] = '#FFFFFF';
        if (background_image[i].className === "g-recaptcha")
            background_image[i].style['color'] = '#000000';
    }

    let table_entries = document.getElementsByTagName('td');
    for (let i = 0; i < table_entries.length; i++) {
        table_entries[i].style['background-color'] = '#000000';
        table_entries[i].style['color'] = '#FFFFFF';
    }

    let table_header = document.getElementsByTagName('th');
    for (let i = 0; i < table_header.length; i++) {
        table_header[i].style['background-color'] = '#FFFFFF';
        table_header[i].style['color'] = '#000000';
    }

    if (!(window.location.href.includes("/ResultCard") && window.location.href.includes("cms.comsats.edu.pk"))){
        let table_root = document.getElementsByTagName('tr');
        for (let i = 0; i < table_root.length; i++) {
            table_root[i].style['background-color'] = '#FFFFFF';
            table_root[i].style['color'] = '#000000';
            table_root[i].style['text-color'] = '#000000';
        }
    }

    let loading_screen = document.getElementsByClassName("se-pre-con");
    for (let i = 0; i < loading_screen.length; i++) {
        loading_screen[i].style['background-color'] = '#000000';
        loading_screen[i].style['color'] = '#000000';
        loading_screen[i].style['text-color'] = '#000000';
    }
}

function removePopups() {
    if (window.location.href.includes("/Courses")) {
        let popup = document.getElementById("myModal");
        if (popup !== null) {
            chrome.storage.local.get(['lastPopup'], function (result) {
                if (result['lastPopup'] === undefined) {
                    chrome.storage.local.set({'lastPopup': popup.textContent}, function () {
                    });
                } else if (result['lastPopup'] === popup.textContent) {
                    popup.style["display"] = "none";
                } else {
                    chrome.storage.local.set({'lastPopup': popup.textContent}, function () {
                    });
                }

            });
        }

    }
    if (window.location.href.includes("/ResultCard")) {
        let popup = document.getElementById("myModal");
        if (popup !== null) {
            chrome.storage.local.get(['lastResultPopup'], function (result) {
                if (result['lastResultPopup'] === undefined) {
                    chrome.storage.local.set({'lastResultPopup': popup.textContent}, function () {
                    });
                } else if (result['lastResultPopup'] === popup.textContent) {
                    popup.style["display"] = "none";
                } else {
                    chrome.storage.local.set({'lastResultPopup': popup.textContent}, function () {});
                }

            });
        }

    }
}

function calculateGpa(){

    if (window.location.href.includes("/ResultCard") && window.location.href.includes("cms.comsats.edu.pk")){
        let tables = document.getElementsByClassName("single_result_container");
        for (let i = 0; i < tables.length; i++){

            let total_gpa = 0;
            let total_credit = 0;
            let total_gpa_into_credit = 0;
            let marks = tables[i].getElementsByClassName("WhiteFormTextResult");
            for (let j = 1; j < marks.length; j++){
                let values = marks[j].getElementsByTagName("td");
                let gpa = parseFloat(values[5].textContent);
                let credit = parseFloat(values[2].textContent);
                if (gpa.toString() !== "NaN") {
                    total_gpa += gpa;
                    total_credit += credit;
                    total_gpa_into_credit += (gpa * credit);
                }
            }
            let gpa_this_semester = Math.round(total_gpa_into_credit/total_credit * 100) / 100;

            let sub_tables = tables[i].getElementsByClassName("table_container");
            let summary_table_body = sub_tables[2].getElementsByTagName("tbody")[0];
            let heading = document.createElement("b");
            let heading_text = document.createTextNode(" GPA : ");
            let value_text = document.createTextNode(gpa_this_semester.toString());
            heading.appendChild(heading_text);
            let td_element = document.createElement("td");
            let tr_element = document.createElement("tr");
            td_element.appendChild(heading);
            td_element.appendChild(value_text);
            tr_element.appendChild(td_element);
            summary_table_body.insertBefore(tr_element, summary_table_body.firstChild);
        }
    }
}

function calculateInternalMarks() {

    if (window.location.href.includes("MarksSummary")){

        let tableContainers = document.getElementsByClassName("table-responsive quiz_listing")[0];
        if (tableContainers === undefined)
            return;
        let credit_element = document.getElementsByClassName("col-md-4 column page_title_container")[0].getElementsByTagName("h5")[0];
        let credit = parseInt(credit_element.textContent.charAt(credit_element.textContent.length - 1));
        let tableHeadings = tableContainers.getElementsByTagName("div");
        let hasLab;
        for (let i = 0; i < tableHeadings.length; i++) {
            if (tableHeadings[i].textContent === "Lab Sessional 1"
                || tableHeadings[i].textContent === "Lab Assignments"
                || tableHeadings[i].textContent === "Lab Sessional 2"
            ) {
                hasLab = true;
                break;
            }
        }
        calculate_weights(hasLab, credit);

        let markType;
        // Loops through Tables
        for (let i = 0; i < tableContainers.childNodes.length; i += 1){
			if (tableContainers.childNodes[i].tagName === "DIV"){
			    markType = tableContainers.childNodes[i].textContent;
            }
			if (tableContainers.childNodes[i].className === "table table-striped table-bordered table-hover"){
                if (markType === "Final")
                    continue;
			    let tableRows = tableContainers.childNodes[i].getElementsByTagName("tbody")[0].getElementsByTagName("tr");
                let marksInstance = complete_marks_data[markType];

                // let marksSubtotalWeight = marksInstance["weight_sub_total"];
                let marksGrandWeight = marksInstance["weight_grand_total"];

                let count = 0;
                let totalMarks = 0;

                // Loops through Table Rows
                for (let j = 0; j < tableRows.length; j++){
                    let singleMarksObtained = parseFloat(tableRows[j].getElementsByTagName("td")[1].textContent);
                    let singleTotalMarks = parseFloat(tableRows[j].getElementsByTagName("td")[2].textContent);
                    marksInstance["total_marks_accounted"] += marksInstance["weight_single_marks"];
                    marksInstance["obtained_marks_accounted"] +=
                        (singleMarksObtained / singleTotalMarks * marksInstance["weight_single_marks"]);

                    totalMarks += singleMarksObtained / singleTotalMarks * 10;
                    count += 1;
                }

                // let marksSubtotalObtained = ((totalMarks / count) / 10) * marksSubtotalWeight;
                let marksGrandTotalObtained = ((totalMarks / count) / 10) * marksGrandWeight;

                // addRow(
                //     tableContainers.childNodes[i].getElementsByTagName("tbody")[0],
                //     "Average (in only Lab/Theory)",
                //     marksSubtotalObtained.toString(),
                //     marksSubtotalWeight.toString(),
                //     ""
                //     );

                addRow(
                    tableContainers.childNodes[i].getElementsByTagName("tbody")[0],
                    "Absolute Marks (average)",
                    (Math.round(marksGrandTotalObtained * roundFigure)/roundFigure).toString(),
                    (Math.round(marksGrandWeight * roundFigure)/roundFigure).toString(),
                    ""
                );
                addRow(
                    tableContainers.childNodes[i].getElementsByTagName("tbody")[0],
                    "Absolute Marks (marked)",
                    (Math.round(marksInstance["obtained_marks_accounted"] * roundFigure)/roundFigure).toString(),
                    (Math.round(marksInstance["total_marks_accounted"] * roundFigure)/roundFigure).toString(),
                    ""
                );

            }
        }
        showInternalMarks();
    }
}

function showInternalMarks() {

    let grandTotal = 0;
    let grandObtained = 0;
    for (let part in complete_marks_data){
        grandTotal += complete_marks_data[part]["total_marks_accounted"];
        grandObtained += complete_marks_data[part]["obtained_marks_accounted"];
    }
    grandTotal = Math.round(grandTotal * roundFigure)/roundFigure
    grandObtained = Math.round(grandObtained * roundFigure)/roundFigure
    let values_html = document.getElementsByClassName("col-md-4 column page_title_container")[0];
    let h5_html = document.createElement("h5");
    h5_html.appendChild(document.createTextNode("Internal Marks : " + grandObtained.toString() + " / " + grandTotal.toString()));
    values_html.appendChild(h5_html);

}

function calculate_weights(hasLab, credit){
    if (!hasLab){
        complete_marks_data["Quizzes"].weight_grand_total = 15;
        complete_marks_data["Quizzes"].weight_sub_total = 15;
        complete_marks_data["Quizzes"].weight_single_marks = 15/4;

        complete_marks_data["Assignments"].weight_grand_total = 10;
        complete_marks_data["Assignments"].weight_sub_total = 10;
        complete_marks_data["Assignments"].weight_single_marks = 10/4;

        complete_marks_data["Sessional 1"].weight_grand_total = 10;
        complete_marks_data["Sessional 1"].weight_sub_total = 10;
        complete_marks_data["Sessional 1"].weight_single_marks = 10;

        complete_marks_data["Sessional 2"].weight_grand_total = 15;
        complete_marks_data["Sessional 2"].weight_sub_total = 15;
        complete_marks_data["Sessional 2"].weight_single_marks = 15;

        complete_marks_data["Final"].weight_grand_total = 50;
        complete_marks_data["Final"].weight_sub_total = 50;
        complete_marks_data["Final"].weight_single_marks = 50;

    }else{
        complete_marks_data["Quizzes"].weight_grand_total = 15 * ((credit-1) / credit);
        complete_marks_data["Quizzes"].weight_sub_total = 15;
        complete_marks_data["Quizzes"].weight_single_marks = (15 * ((credit-1) / credit))/4;

        complete_marks_data["Assignments"].weight_grand_total = 10 * ((credit-1) / credit);
        complete_marks_data["Assignments"].weight_sub_total = 10;
        complete_marks_data["Assignments"].weight_single_marks = (10 * ((credit-1) / credit))/4;

        complete_marks_data["Sessional 1"].weight_grand_total = 10 * ((credit-1) / credit);
        complete_marks_data["Sessional 1"].weight_sub_total = 10;
        complete_marks_data["Sessional 1"].weight_single_marks = 10 * ((credit-1) / credit);

        complete_marks_data["Sessional 2"].weight_grand_total = 15 * ((credit-1) / credit);
        complete_marks_data["Sessional 2"].weight_sub_total = 15;
        complete_marks_data["Sessional 2"].weight_single_marks = 15 * ((credit-1) / credit);

        complete_marks_data["Final"].weight_grand_total = 50 * ((credit-1) / credit);
        complete_marks_data["Final"].weight_sub_total = 50;
        complete_marks_data["Final"].weight_single_marks = 50 * ((credit-1) / credit);

        complete_marks_data["Lab Sessional 1"].weight_grand_total = 10 * (1 / credit);
        complete_marks_data["Lab Sessional 1"].weight_sub_total = 10;
        complete_marks_data["Lab Sessional 1"].weight_single_marks = 10 * (1 / credit);

        complete_marks_data["Lab Sessional 2"].weight_grand_total = 15 * (1 / credit);
        complete_marks_data["Lab Sessional 2"].weight_sub_total = 15;
        complete_marks_data["Lab Sessional 2"].weight_single_marks = 15 * (1 / credit);

        complete_marks_data["Lab Assignments"].weight_grand_total = 25 * (1 / credit);
        complete_marks_data["Lab Assignments"].weight_sub_total = 25;
        complete_marks_data["Lab Assignments"].weight_single_marks = (25 * (1 / credit))/4;

        complete_marks_data["FinalLab"].weight_grand_total = 50 * (1 / credit);
        complete_marks_data["FinalLab"].weight_sub_total = 50;
        complete_marks_data["FinalLab"].weight_single_marks = 50 * (1 / credit);
    }
}

function addRow(root, value1, value2, value3, value4) {
    let html_title = document.createTextNode(value1);
    let html_obtained_marks = document.createTextNode(value2);
    let html_total_marks = document.createTextNode(value3);
    let html_dud = document.createTextNode(value4);

    let html_title_column = document.createElement("td");
    let html_obtained_marks_column = document.createElement("td");
    let html_total_marks_column = document.createElement("td");
    let html_dud_column = document.createElement("td");

    html_title_column.appendChild(html_title);
    html_obtained_marks_column.appendChild(html_obtained_marks);
    html_total_marks_column.appendChild(html_total_marks);
    html_dud_column.appendChild(html_dud);

    let newRow = document.createElement("tr");

    newRow.appendChild(html_title_column);
    newRow.appendChild(html_obtained_marks_column);
    newRow.appendChild(html_total_marks_column);
    newRow.appendChild(html_dud_column);

    root.appendChild(newRow);
}

function init(){

    if (window.location.href.includes("/ResultCard")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastResultPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastResultPopup': "placeholder"}, function() {});
    }
    if (window.location.href.includes("/Courses")) {
        let popup = document.getElementById("myModal");
        if (popup !== null)
            chrome.storage.local.set({'lastPopup': popup.textContent}, function() {});
        else
            chrome.storage.local.set({'lastPopup': "placeholder"}, function() {});
    }

    chrome.storage.local.get(['setDarkMode', 'gpaCalculate', 'marksCalculate', 'removePopup'], function(result) {
        if (result['gpaCalculate'] === undefined){
            chrome.storage.local.set({'gpaCalculate': true}, function() {});
            calculateGpa();
        }
        else {
            if (result['gpaCalculate']){
                calculateGpa();
            }
        }

        if (result['marksCalculate'] === undefined){
            chrome.storage.local.set({'marksCalculate': true}, function() {});
            calculateInternalMarks();
        }
        else{
            if (result['marksCalculate']){
                calculateInternalMarks();
            }
        }

        if (result['removePopup'] === undefined){
            chrome.storage.local.set({'removePopup': false}, function() {});
        }
        else{
            if (result['removePopup']){
                removePopups();
            }
        }

        if (result['setDarkMode'] === undefined){
            chrome.storage.local.set({'setDarkMode': false}, function() {});
        }
        else{
            if (result['setDarkMode']){
                darkMode();
            }
        }
    });
}

init();




